SELECT
  *
FROM
  lakehouse.telemetry.device
