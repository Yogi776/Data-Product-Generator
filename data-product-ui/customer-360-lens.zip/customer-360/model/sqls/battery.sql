SELECT
  *
FROM
  lakehouse.telemetry.battery
